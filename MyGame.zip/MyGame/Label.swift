//
//  Label.swift
//  MyGame
//
//  Created by Sajan Shah on 9/1/20.
//  Copyright © 2020 Sajan Shah. All rights reserved.
//

import Foundation

class Label {
    
    var isMatched = false
    var isFlipped = false
    var expression = ""
    var value = 0
}
