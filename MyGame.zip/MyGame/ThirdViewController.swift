//
//  ThirdViewController.swift
//  MyGame
//
//  Created by Sajan Shah on 10/7/20.
//  Copyright © 2020 Sajan Shah. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func close(_ sender: Any) {
    
        self.dismiss(animated: false, completion: nil)
    }
}
